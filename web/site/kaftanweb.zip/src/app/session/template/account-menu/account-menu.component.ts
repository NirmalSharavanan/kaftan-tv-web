import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ss-account-menu',
  templateUrl: './account-menu.component.html',
  styleUrls: ['./account-menu.component.scss']
})
export class AccountMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
