import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-singnup-confirmation',
  templateUrl: './singnup-confirmation.component.html'
})
export class SingnupConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
