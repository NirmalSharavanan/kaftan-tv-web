export class subscriptionPlan {
    paymentAmount : number;
    subscriptionStarted_at : string;
    subscriptionEnd_at: string;
    paymentMode: string;
    referenceNumber: string;
    transactionId: string;
    
}