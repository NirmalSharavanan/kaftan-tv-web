export class PayUserInfo {
    key_id: string;
    customer_name: string;
    logo_url: string;
    user_name: string;
    user_email: string;
    amount: number;
    razorpay_subscription_id: string;
}