export class PaymentCompleted  {
    product_reference_id: string;
}
