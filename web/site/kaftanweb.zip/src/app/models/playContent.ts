import { AWSInfo } from './awsInfo';

export class PlayContent {
   awsInfo: AWSInfo;
   isAuthenticated: boolean;
   is_premium: boolean;
   has_access_to_preminum: boolean;
}
