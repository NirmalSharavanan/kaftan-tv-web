export class ResponseBase {
    success: boolean;
    message: string;
}
