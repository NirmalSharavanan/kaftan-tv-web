
export class AWSUploadStatus {
    qualityType: string;
    key: string;
    ETag: string;
}
