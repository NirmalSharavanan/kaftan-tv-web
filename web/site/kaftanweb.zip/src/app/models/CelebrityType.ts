import { ResponseBase } from 'app/models/responseBase';

export class CelebrityType extends ResponseBase {
    id: string;
    name: string;
}
