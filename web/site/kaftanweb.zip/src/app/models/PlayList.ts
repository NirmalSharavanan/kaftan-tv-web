export class PlayList {
    id: string;
    name: string;
    contentList: Array<string>;
}