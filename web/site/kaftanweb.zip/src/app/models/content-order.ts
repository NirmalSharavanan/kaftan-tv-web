import { Content } from './content';

export class ContentOrder {
    sort_order: number;
    content: Content;
}
