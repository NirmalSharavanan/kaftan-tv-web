export class VideoPlayInfo  {
    isYouTubeUrl: string;
    sdVideoUrl: string;
    hdVideoUrl: string;
    audioBanner: string;
    audioThumbnail: string;
    title: string;
}
