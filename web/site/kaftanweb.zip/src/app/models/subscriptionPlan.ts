export class subscriptionPlan {
    id: string;
    paymentPlan : string;
    amount : number;
    is_Active: boolean;
    features: Array<string>;
}