import { PaymentCompleted } from './PaymentCompleted';

export class PaymentInfo {
    paymentCompletedList: Array<PaymentCompleted>;
}
