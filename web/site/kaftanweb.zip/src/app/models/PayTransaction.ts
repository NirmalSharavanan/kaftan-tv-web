
export class PayTransaction {
    razorpay_payment_id: string;
    product_reference_id: string;
    amount: number;
}
