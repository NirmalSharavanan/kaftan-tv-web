export class ReOrder {
    constructor(public id: string, public sort_order: number) { }
}

