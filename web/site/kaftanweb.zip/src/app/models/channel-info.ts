export class ChannelInfo {
    videoTitle: string;
    videoUrl: string;
    banner: string;
}
