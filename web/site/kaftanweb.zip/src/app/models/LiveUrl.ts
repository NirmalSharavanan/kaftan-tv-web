import { ResponseBase } from 'app/models/responseBase';

export class LiveUrl extends ResponseBase {
    live480Url: string;
}
