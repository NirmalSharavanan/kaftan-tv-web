export class AWSConfig {
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
  bucket: string;
}
