export class QualityType {
    static ORIGINAL = 'original';
    static P_1080 = '1080';
    static P_720 = '720';
    static P_480 = '480';
    static P_360 = '360';
}
