export class ApplicationException {
    constructor(private actualError?: Error) { }
}
