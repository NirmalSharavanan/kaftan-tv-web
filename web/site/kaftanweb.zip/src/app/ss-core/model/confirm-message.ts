export class ConfrimMessage {
    constructor(public message: string, public navigation?: string, public severity: string = 'info') { }
}
