import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ss-add-edit-promotion',
  templateUrl: './add-edit-promotion.component.html',
  styleUrls: ['./add-edit-promotion.component.scss']
})
export class AddEditPromotionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
